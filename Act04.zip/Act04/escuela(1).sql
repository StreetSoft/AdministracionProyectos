-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 08-06-2019 a las 02:04:14
-- Versión del servidor: 10.1.36-MariaDB
-- Versión de PHP: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `escuela`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `alumnos`
--

CREATE TABLE `alumnos` (
  `curp_Alumno` varchar(15) NOT NULL,
  `nombreAlumno` varchar(30) DEFAULT NULL,
  `contrasena_Alum` varchar(15) DEFAULT NULL,
  `id_Grupo` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `alumnos`
--

INSERT INTO `alumnos` (`curp_Alumno`, `nombreAlumno`, `contrasena_Alum`, `id_Grupo`) VALUES
('DJ48', 'David Josue', '12345e', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `calificaciones`
--

CREATE TABLE `calificaciones` (
  `id_Calificacion` int(11) NOT NULL,
  `calificacion` int(11) DEFAULT NULL,
  `curp_Profesor` varchar(15) DEFAULT NULL,
  `curp_Alumno` varchar(15) DEFAULT NULL,
  `id_Materias` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `colegiaturas`
--

CREATE TABLE `colegiaturas` (
  `id_Colegiatura` int(11) NOT NULL,
  `curp_Alumno` varchar(15) DEFAULT NULL,
  `ficha` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `comentarios`
--

CREATE TABLE `comentarios` (
  `id_Comentario` int(11) NOT NULL,
  `contenidoCon` text,
  `fechaC` date DEFAULT NULL,
  `curp_Usuario` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `grupos`
--

CREATE TABLE `grupos` (
  `id_Grupo` int(11) NOT NULL,
  `nombregRUPO` varchar(10) DEFAULT NULL,
  `curp_profesor` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `materias`
--

CREATE TABLE `materias` (
  `id_Materias` int(11) NOT NULL,
  `nombreMateria` varchar(15) DEFAULT NULL,
  `curp_Profesor` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `noticias`
--

CREATE TABLE `noticias` (
  `id_Noticia` int(11) NOT NULL,
  `contenido` text,
  `fechaN` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pribvilegios`
--

CREATE TABLE `pribvilegios` (
  `id_Privilegios` int(11) NOT NULL,
  `nombrePrivilegios` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `profesores`
--

CREATE TABLE `profesores` (
  `curp_Profesor` varchar(15) NOT NULL,
  `nombreProfesor` varchar(30) DEFAULT NULL,
  `correoProfesor` varchar(30) DEFAULT NULL,
  `contraseniaProfe` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `curp_usuario` varchar(15) NOT NULL,
  `nombreUsuario` varchar(30) DEFAULT NULL,
  `correo` varchar(30) DEFAULT NULL,
  `contrasenia` varchar(15) DEFAULT NULL,
  `id_Privilegios` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `alumnos`
--
ALTER TABLE `alumnos`
  ADD PRIMARY KEY (`curp_Alumno`),
  ADD KEY `id_Grupo` (`id_Grupo`),
  ADD KEY `curp_Alumno` (`curp_Alumno`);

--
-- Indices de la tabla `calificaciones`
--
ALTER TABLE `calificaciones`
  ADD PRIMARY KEY (`id_Calificacion`),
  ADD KEY `id_Calificacion` (`id_Calificacion`),
  ADD KEY `curp_Profesor` (`curp_Profesor`),
  ADD KEY `curp_Alumno` (`curp_Alumno`),
  ADD KEY `id_Materias` (`id_Materias`);

--
-- Indices de la tabla `colegiaturas`
--
ALTER TABLE `colegiaturas`
  ADD PRIMARY KEY (`id_Colegiatura`);

--
-- Indices de la tabla `comentarios`
--
ALTER TABLE `comentarios`
  ADD PRIMARY KEY (`id_Comentario`),
  ADD KEY `curp_Usuario` (`curp_Usuario`);

--
-- Indices de la tabla `grupos`
--
ALTER TABLE `grupos`
  ADD PRIMARY KEY (`id_Grupo`),
  ADD KEY `id_Grupo` (`id_Grupo`),
  ADD KEY `curp_profesor` (`curp_profesor`);

--
-- Indices de la tabla `materias`
--
ALTER TABLE `materias`
  ADD PRIMARY KEY (`id_Materias`),
  ADD KEY `id_Materias` (`id_Materias`),
  ADD KEY `curp_Profesor` (`curp_Profesor`);

--
-- Indices de la tabla `noticias`
--
ALTER TABLE `noticias`
  ADD PRIMARY KEY (`id_Noticia`);

--
-- Indices de la tabla `pribvilegios`
--
ALTER TABLE `pribvilegios`
  ADD PRIMARY KEY (`id_Privilegios`);

--
-- Indices de la tabla `profesores`
--
ALTER TABLE `profesores`
  ADD PRIMARY KEY (`curp_Profesor`),
  ADD KEY `curp_Profesor` (`curp_Profesor`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`curp_usuario`),
  ADD KEY `curp_usuario` (`curp_usuario`),
  ADD KEY `id_Privilegios` (`id_Privilegios`);

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `calificaciones`
--
ALTER TABLE `calificaciones`
  ADD CONSTRAINT `calificaciones_ibfk_1` FOREIGN KEY (`curp_Alumno`) REFERENCES `alumnos` (`curp_Alumno`),
  ADD CONSTRAINT `calificaciones_ibfk_2` FOREIGN KEY (`curp_Profesor`) REFERENCES `profesores` (`curp_Profesor`),
  ADD CONSTRAINT `calificaciones_ibfk_3` FOREIGN KEY (`id_Materias`) REFERENCES `materias` (`id_Materias`);

--
-- Filtros para la tabla `comentarios`
--
ALTER TABLE `comentarios`
  ADD CONSTRAINT `comentarios_ibfk_1` FOREIGN KEY (`curp_Usuario`) REFERENCES `usuarios` (`curp_usuario`);

--
-- Filtros para la tabla `grupos`
--
ALTER TABLE `grupos`
  ADD CONSTRAINT `grupos_ibfk_1` FOREIGN KEY (`curp_profesor`) REFERENCES `profesores` (`curp_Profesor`);

--
-- Filtros para la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD CONSTRAINT `usuarios_ibfk_1` FOREIGN KEY (`id_Privilegios`) REFERENCES `pribvilegios` (`id_Privilegios`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
